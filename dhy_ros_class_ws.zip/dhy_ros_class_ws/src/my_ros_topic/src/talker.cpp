#include "ros/ros.h"
#include "std_msgs/String.h"
#include <sstream>

int main(int argc, char **argv)
{
    // 初始化ROS节点，节点名：talker
    ros::init(argc, argv, "talker");
    
    // 创建节点句柄
    ros::NodeHandle n;

    // 创建发布者：话题名 /chatter，消息类型 std_msgs/String，队列大小10
    ros::Publisher chatter_pub = n.advertise<std_msgs::String>("chatter", 10);

    // 循环频率 10Hz
    ros::Rate loop_rate(10);

    int count = 0;
    while (ros::ok())
    {
        // 定义消息
        std_msgs::String msg;
        std::stringstream ss;
        ss << "Hello ROS! 第 " << count << " 条消息";
        msg.data = ss.str();

        // 打印发送的内容
        ROS_INFO("发送：%s", msg.data.c_str());

        // 发布消息
        chatter_pub.publish(msg);

        // 处理回调
        ros::spinOnce();

        // 按照频率休眠
        loop_rate.sleep();
        count++;
    }
    return 0;
}
