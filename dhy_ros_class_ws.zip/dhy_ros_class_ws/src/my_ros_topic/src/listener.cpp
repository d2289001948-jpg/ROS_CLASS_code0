#include "ros/ros.h"
#include "std_msgs/String.h"

// 回调函数：收到消息时自动执行
void chatterCallback(const std_msgs::String::ConstPtr& msg)
{
    // 打印收到的消息
    ROS_INFO("收到：%s", msg->data.c_str());
}

int main(int argc, char **argv)
{
    // 初始化ROS节点，节点名：listener
    ros::init(argc, argv, "listener");
    
    ros::NodeHandle n;

    // 创建订阅者：订阅 /chatter 话题，回调函数 chatterCallback
    ros::Subscriber sub = n.subscribe("chatter", 10, chatterCallback);

    // 循环等待回调
    ros::spin();

    return 0;
}
